import { Component, OnInit } from '@angular/core';

import { ApiService } from 'src/app/services/api.service';


@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.page.html',
  styleUrls: ['./formulario.page.scss'],
})
export class FormularioPage implements OnInit {

  comuna: any[] = [
    {id: 1, nombreComuna: "Santiago"},
    {id: 2, nombreComuna: "Conchalí"},
    {id: 3, nombreComuna: "EL Bosque"},
    {id: 4, nombreComuna: "La Cisterna"},
    {id: 5, nombreComuna: "Quilicura"},
    {id: 6, nombreComuna: "Recoleta"},
    {id: 7, nombreComuna: "Renca"},
    {id: 8, nombreComuna: "La Pintana"}
  ]

  modeloRut: string;
  modeloPrimerNombre: string;
  modeloSegundoNombre: string;
  modeloApPaterno: string;
  modeloApMaterno: string;
  modeloNacimiento: string;
  modeloCorreo: string;
  modeloComuna: string;
  modeloCalle: string;
  modeloNumeracion: string;
  modeloContrasena: string;

  constructor(
    public apiService: ApiService ) {

  }

  ngOnInit() {
  }

  
  registrarUsuario(){
    let data = {
      rut: this.modeloRut,
      primer_nombre: this.modeloPrimerNombre,
      segundo_nombre: this.modeloSegundoNombre,
      apellido_paterno: this.modeloApPaterno,
      apellido_materno: this.modeloApMaterno,
      fecha_nacimiento: this.modeloNacimiento,
      correo: this.modeloCorreo,
      comuna: this.modeloComuna,
      calle: this.modeloCalle,
      numeracion: this.modeloNumeracion,
      contrasena: this.modeloContrasena

    }
    
    this.apiService.registrarUsuario(data).subscribe((res:any)=>{
      console.log("SUCCESS ===",res);
      this.modeloRut ='';
      this.modeloPrimerNombre='';
      this.modeloSegundoNombre='';
      this.modeloApPaterno='';
      this.modeloApMaterno='';
      this.modeloNacimiento = '';
      this.modeloCorreo='';
      this.modeloComuna='';
      this.modeloCalle='';
      this.modeloNumeracion='';
      this.modeloContrasena='';

      alert('SUCCESS');
    },(error: any) => {
      alert('Se ha guardado correctamente');
      console.log("guardado", error);
    })
  }

}
