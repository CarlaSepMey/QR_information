import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examenes',
  templateUrl: './examenes.page.html',
  styleUrls: ['./examenes.page.scss'],
})
export class ExamenesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
