import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';// 1 estructura,2 como se llama el formulario



@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  formulario:FormGroup;
  mensaje: string;

  modeloRut: String;
  modeloContrasena: String;

  constructor(private http: HttpClient, private form:FormBuilder,  ) {
      this.formulario=this.form.group({
        modeloRut: ['', Validators.required],
        modeloContrasena: ['', Validators.required]
      });
     
  }

  ngOnInit() {
  } 

  ingresar(){

  }

  //ingresar(){
  // this.http.post('',{"modeloRut":this.modeloRut, "modeloContrasena":this.modeloContrasena}).subscribe((data:any)=>{
  //   console.log(data);
  //    if(data.status==200){
  //     alert("ok");
  //   }
  //  })
  //}
}
